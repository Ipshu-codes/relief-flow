// Rahat dashboard shell.
// Plain ES modules, no bundler, no external requests. Incidents come from
// /api/v1/incidents + the WebSocket stream; the Nepal basemap is rendered from
// the offline GeoJSON in dashboard/data (built by scripts/build_map_assets.py).

const SEVERITY = {
  critical: { label: "Critical", rank: 4 },
  high: { label: "High", rank: 3 },
  medium: { label: "Medium", rank: 2 },
  low: { label: "Low", rank: 1 },
};

const sampleIncidents = [
  {
    id: 41,
    title: "Collapsed building, Boudha",
    category: "trapped",
    severity: "critical",
    priority: 92.5,
    status: "triaged",
    area: "Boudha",
    ageMin: 8,
    people: 4,
    reports: 3,
    lat: 27.7215,
    lon: 85.362,
    confidence: 0.81,
    explanation: "Children trapped under debris; medical need; no prior response.",
    raw: "घर भत्कियो, ४ जना फसेका छन्। बच्चाहरू पनि छन्। नजिकै बौद्ध स्तूप।",
    needs: ["rescue", "medical"],
    hazards: ["collapsed_building", "aftershock"],
    volunteer: "V12 · Sita Tamang (rescue, first aid) · 14 min",
  },
  {
    id: 38,
    title: "Flood water rising, Sinamangal",
    category: "flood",
    severity: "high",
    priority: 78.0,
    status: "assigned",
    area: "Sinamangal",
    ageMin: 21,
    people: 12,
    reports: 2,
    lat: 27.6939,
    lon: 85.3527,
    confidence: 0.74,
    explanation: "Ground floor flooded; elderly and children need evacuation.",
    raw: "पानी घरभित्र पसिसक्यो। बूढाबूढी र बच्चा छन्, निकाल्नु पर्छ।",
    needs: ["evacuation", "shelter"],
    hazards: ["flood"],
    volunteer: "V07 · Ram Shrestha (boat, driving) · 22 min",
  },
  {
    id: 35,
    title: "Food and water shortage, Kirtipur",
    category: "food_water",
    severity: "medium",
    priority: 61.0,
    status: "new",
    area: "Kirtipur",
    ageMin: 46,
    people: 30,
    reports: 1,
    lat: 27.6795,
    lon: 85.279,
    confidence: 0.66,
    explanation: "Shelter has 30 people with no water for six hours.",
    raw: "आश्रयस्थलमा ३० जना छौं, पानी सकियो। खाना पनि छैन।",
    needs: ["water", "food"],
    hazards: ["supply_gap"],
    volunteer: "Unassigned",
  },
  {
    id: 31,
    title: "Blocked road, Ring Road north",
    category: "road_blocked",
    severity: "high",
    priority: 70.0,
    status: "triaged",
    area: "Ring Road",
    ageMin: 12,
    people: 0,
    reports: 4,
    lat: 27.735,
    lon: 85.315,
    confidence: 0.9,
    explanation: "Landslide debris blocks both lanes; two routes affected.",
    raw: "रिङ रोड उत्तरतर्फ पहिरोले बाटो बन्द भएको छ।",
    needs: ["clearance"],
    hazards: ["landslide"],
    volunteer: "Reroute triggered",
  },
  {
    id: 29,
    title: "Missing person, Patan",
    category: "missing",
    severity: "low",
    priority: 44.0,
    status: "new",
    area: "Patan",
    ageMin: 95,
    people: 1,
    reports: 1,
    lat: 27.6727,
    lon: 85.325,
    confidence: 0.58,
    explanation: "Elderly man last seen near the Durbar Square shelter.",
    raw: "६८ वर्षीय बुबा हराउनुभयो। पाटन दरबार क्षेत्र नजिकै।",
    needs: ["search"],
    hazards: [],
    volunteer: "Unassigned",
  },
];

const state = {
  incidents: [],
  selectedId: null,
  query: "",
  status: "open",
  sessions: {}, // incident_id -> latest agent session
  ws: null,
};

const $ = (sel) => document.querySelector(sel);
const el = (tag, className, text) => {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
};

// ---------- Data loading ----------

function severityForPriority(priority) {
  if (priority >= 85) return "critical";
  if (priority >= 70) return "high";
  if (priority >= 40) return "medium";
  return "low";
}

// The API returns the raw incident row; the sample data is already shaped for
// the UI. Normalise both so every field the queue/map/detail use exists.
function normalizeIncident(raw) {
  const priority = typeof raw.priority === "number" ? raw.priority : null;
  const category = String(raw.category || "other");
  const lat = typeof raw.lat === "number" ? raw.lat : null;
  const lon = typeof raw.lon === "number" ? raw.lon : null;
  const words = category.replaceAll("_", " ");
  const timestamp = raw.last_update || raw.first_report_at || null;
  return {
    ...raw,
    title: raw.title || `${words.charAt(0).toUpperCase()}${words.slice(1)} incident`,
    category,
    severity: raw.severity || severityForPriority(priority ?? 0),
    priority: priority ?? 0,
    lat,
    lon,
    area:
      raw.area ||
      (lat !== null && lon !== null ? `${lat.toFixed(4)}, ${lon.toFixed(4)}` : "Unknown area"),
    ageMin:
      raw.ageMin ??
      (timestamp ? Math.max(0, Math.round((Date.now() / 1000 - timestamp) / 60)) : 0),
    people: raw.people ?? raw.people_affected ?? 0,
    reports: raw.reports ?? raw.report_count ?? 0,
    confidence: raw.confidence ?? raw.ai_confidence ?? 0,
    explanation: raw.explanation || raw.priority_explanation || "Awaiting AI triage.",
    raw: raw.raw || "—",
    needs: raw.needs || [],
    hazards: raw.hazards || [],
    volunteer: raw.volunteer || "Unassigned",
    status: raw.status || "new",
  };
}

async function loadIncidents() {
  try {
    const response = await fetch("/api/v1/incidents", {
      headers: { Accept: "application/json" },
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    state.incidents = await response.json();
  } catch {
    state.incidents = sampleIncidents;
  }
  state.incidents = state.incidents.map(normalizeIncident);
}

// ---------- WebSocket ----------

function connectWS() {
  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
  const wsUrl = `${protocol}//${window.location.host}/api/v1/ws/stream`;
  let ws;
  try {
    ws = new WebSocket(wsUrl);
  } catch {
    return;
  }
  state.ws = ws;
  ws.onopen = () => {
    $("#health-status").textContent = "● live";
  };
  ws.onclose = () => {
    state.ws = null;
    setTimeout(connectWS, 3000);
  };
  ws.onmessage = (event) => {
    try {
      const msg = JSON.parse(event.data);
      if (msg.event === "incident.created") {
        loadIncidents().then(() => {
          renderQueue();
          renderMap();
        });
      }
      if (msg.event === "agent.completed" || msg.event === "agent.approved" || msg.event === "agent.rejected") {
        const { incident_id } = msg.data || {};
        if (incident_id) {
          fetchSessionTrace(incident_id);
        }
      }
    } catch {
      // ignore malformed messages
    }
  };
  ws.onerror = () => {
    ws.close();
  };
}

// ---------- Agent trace ----------

async function fetchSessionTrace(incidentId) {
  try {
    const response = await fetch(`/api/v1/agent/sessions?incident_id=${incidentId}`);
    if (!response.ok) return;
    const sessions = await response.json();
    if (!sessions || sessions.length === 0) return;
    const latest = sessions[0];
    state.sessions[incidentId] = latest;
    if (state.selectedId === incidentId) {
      renderDetail();
    }
  } catch {
    // ignore
  }
}

// ---------- Queue ----------

function visibleIncidents() {
  return state.incidents
    .filter((i) => (state.status === "all" ? true : i.status !== "resolved"))
    .filter((i) => {
      const q = state.query.trim().toLowerCase();
      if (!q) return true;
      return `${i.title} ${i.area} ${i.category}`.toLowerCase().includes(q);
    })
    .sort((a, b) => b.priority - a.priority);
}

function renderQueue() {
  const list = $("#queue");
  const items = visibleIncidents();
  list.replaceChildren();

  $("#queue-count").textContent = `${items.length} open`;

  for (const incident of items) {
    const li = el("li");
    const button = el("button", `queue-item sev-${incident.severity}`);
    button.type = "button";
    button.dataset.id = String(incident.id);
    if (incident.id === state.selectedId) button.classList.add("selected");

    const row = el("div", "queue-row");
    row.append(el("span", "queue-title", incident.title));
    row.append(el("span", "queue-score", incident.priority.toFixed(1)));

    const meta = el("div", "queue-meta");
    meta.append(el("span", `chip sev-${incident.severity}`, SEVERITY[incident.severity].label));
    meta.append(el("span", "chip", `${incident.ageMin} min`));
    meta.append(el("span", "chip", `${incident.people} people`));
    meta.append(el("span", "chip", `${incident.reports} report${incident.reports > 1 ? "s" : ""}`));
    meta.append(el("span", "chip ai", `🤖 ${Math.round(incident.confidence * 100)}%`));

    button.append(row, meta);
    button.addEventListener("click", () => selectIncident(incident.id));
    li.append(button);
    list.append(li);
  }
}

// ---------- Detail ----------

function selectIncident(id) {
  state.selectedId = id;
  renderQueue();
  renderDetail();
  fetchSessionTrace(id);
}

function renderDetail() {
  const incident = state.incidents.find((i) => i.id === state.selectedId);
  const empty = $("#detail-empty");
  const body = $("#detail-body");

  if (!incident) {
    empty.classList.remove("hidden");
    body.classList.add("hidden");
    return;
  }
  empty.classList.add("hidden");
  body.classList.remove("hidden");

  body.replaceChildren();
  body.append(el("h3", null, incident.title));

  const meta = el("div", "queue-meta");
  meta.append(el("span", `chip sev-${incident.severity}`, SEVERITY[incident.severity].label));
  meta.append(el("span", "chip", incident.status));
  meta.append(el("span", "chip ai", "🤖 AI triaged"));
  body.append(meta);

  body.append(el("h4", null, "Why"));
  body.append(el("p", null, incident.explanation));

  const kv = el("dl", "keyvals");
  const pairs = [
    ["Category", incident.category.replaceAll("_", " ")],
    ["Area", incident.area],
    [
      "Coordinates",
      typeof incident.lat === "number" && typeof incident.lon === "number"
        ? `${incident.lat.toFixed(5)}, ${incident.lon.toFixed(5)}`
        : "Unknown",
    ],
    ["People", String(incident.people)],
    ["Needs", incident.needs.join(", ") || "—"],
    ["Hazards", incident.hazards.join(", ") || "—"],
    ["Proposed", incident.volunteer],
  ];
  for (const [key, value] of pairs) {
    kv.append(el("dt", null, key), el("dd", null, value));
  }
  body.append(kv);

  body.append(el("h4", null, "Raw report"));
  body.append(el("p", "raw", incident.raw));

  const session = state.sessions[incident.id] || null;
  body.append(el("h4", null, "Agent trace"));
  const trace = el("div", "trace");
  if (!session) {
    trace.append(el("div", "trace-step", "No agent session for this incident yet."));
  } else {
    const decision = (() => {
      try {
        return session.decision ? JSON.parse(session.decision) : {};
      } catch {
        return {};
      }
    })();
    const steps = session.steps || [];
    if (steps.length === 0) {
      trace.append(el("div", "trace-step", "No tool steps recorded."));
    }
    for (const st of steps) {
      const step = el("div", "trace-step");
      const tierChip = st.tier ? el("span", "chip", st.tier) : null;
      step.append(el("code", null, st.tool));
      if (tierChip) step.append(tierChip);
      step.append(document.createTextNode(` → ${st.policy_decision}`));
      const resultDiv = el("div", "trace-step");
      resultDiv.textContent = `result: ${st.result}`;
      trace.append(step, resultDiv);
    }
    body.append(trace);
    body.append(el("p", null, `Decision: ${(decision.summary || "—")} (confidence ${(decision.confidence * 100).toFixed(0)}%)`));
  }

  const actions = el("div", "actions");
  const approve = el("button", "btn primary", "Approve proposal");
  approve.type = "button";
  const reject = el("button", "btn", "Reject");
  reject.type = "button";
  if (!session || session.status !== "awaiting_approval") {
    approve.disabled = true;
    reject.disabled = true;
    approve.title = "No pending proposal";
    reject.title = "No pending proposal";
  } else {
    approve.onclick = async () => {
      await fetch(`/api/v1/agent/sessions/${session.id}/approve`, { method: "POST" });
      await fetchSessionTrace(incident.id);
    };
    reject.onclick = async () => {
      await fetch(`/api/v1/agent/sessions/${session.id}/reject`, { method: "POST" });
      await fetchSessionTrace(incident.id);
    };
  }
  actions.append(approve, reject);
  body.append(actions);
}

// ---------- Map (Nepal, offline province boundaries) ----------

// Country / routing-extract bounding box in WGS84. Every SOS is plotted at the
// coordinates the phone reported, so the map answers "where did this come from?".
const NEPAL = { north: 30.6, south: 26.28, west: 80.0, east: 88.3 };
NEPAL.cos = Math.cos(((NEPAL.north + NEPAL.south) / 2) * (Math.PI / 180));
const NEPAL_CENTER = {
  lat: (NEPAL.north + NEPAL.south) / 2,
  lon: (NEPAL.east + NEPAL.west) / 2,
};

const MAP_WIDTH = 800;
const MAP_HEIGHT = 600;
const MAP_PADDING = 24;
const MAP_NS = "http://www.w3.org/2000/svg";

// Cities labelled at country scale (the rest are dots with tooltips).
const MAJOR_CITIES = new Set([
  "Kathmandu",
  "Pokhara",
  "Biratnagar",
  "Birganj",
  "Dharan",
  "Butwal",
  "Nepalganj",
  "Hetauda",
  "Janakpur",
  "Birendranagar",
  "Dhangadhi",
  "Ilam",
  "Jomsom",
]);

// Basemap geometry is fetched once from the static dashboard directory
// (built by scripts/build_map_assets.py) and kept in memory.
const mapState = {
  geometry: null,
  loading: false,
  failed: false,
  view: { ...NEPAL_CENTER, zoom: 1 },
};

function svgEl(tag, attributes = {}, text) {
  const node = document.createElementNS(MAP_NS, tag);
  for (const [key, value] of Object.entries(attributes)) {
    node.setAttribute(key, value);
  }
  if (text !== undefined) node.textContent = text;
  return node;
}

// Equirectangular projection that keeps Nepal's aspect ratio.
function baseProject(lat, lon) {
  const lonSpan = (NEPAL.east - NEPAL.west) * NEPAL.cos;
  const latSpan = NEPAL.north - NEPAL.south;
  const scale = Math.min(
    (MAP_WIDTH - MAP_PADDING * 2) / lonSpan,
    (MAP_HEIGHT - MAP_PADDING * 2) / latSpan
  );
  const x0 = (MAP_WIDTH - lonSpan * scale) / 2;
  const y0 = (MAP_HEIGHT - latSpan * scale) / 2;
  return [
    x0 + (lon - NEPAL.west) * NEPAL.cos * scale,
    y0 + (NEPAL.north - lat) * scale,
  ];
}

function project(lat, lon) {
  const [bx, by] = baseProject(lat, lon);
  const [cx, cy] = baseProject(mapState.view.lat, mapState.view.lon);
  return [
    MAP_WIDTH / 2 + (bx - cx) * mapState.view.zoom,
    MAP_HEIGHT / 2 + (by - cy) * mapState.view.zoom,
  ];
}

async function loadMapGeometry() {
  if (mapState.geometry || mapState.loading) return mapState.geometry;
  mapState.loading = true;
  try {
    const [states, hq] = await Promise.all([
      fetch("/static/data/nepal_states.geojson").then((r) => {
        if (!r.ok) throw new Error(`states HTTP ${r.status}`);
        return r.json();
      }),
      fetch("/static/data/nepal_hq.geojson").then((r) => {
        if (!r.ok) throw new Error(`hq HTTP ${r.status}`);
        return r.json();
      }),
    ]);
    mapState.geometry = {
      provinces: states.features || [],
      headquarters: hq.features || [],
    };
  } catch {
    mapState.failed = true;
    mapState.geometry = { provinces: [], headquarters: [] };
  } finally {
    mapState.loading = false;
  }
  return mapState.geometry;
}

function ringToPath(ring) {
  if (!ring || ring.length === 0) return "";
  const points = ring.map(([lon, lat]) => project(lat, lon));
  const [first, ...rest] = points;
  return (
    `M${first[0].toFixed(1)},${first[1].toFixed(1)}` +
    rest.map(([x, y]) => `L${x.toFixed(1)},${y.toFixed(1)}`).join("") +
    "Z"
  );
}

function geometryToPath(geometry) {
  if (!geometry) return "";
  if (geometry.type === "Polygon") return geometry.coordinates.map(ringToPath).join("");
  if (geometry.type === "MultiPolygon") {
    return geometry.coordinates.flatMap((polygon) => polygon.map(ringToPath)).join("");
  }
  return "";
}

function renderMap() {
  const svg = $("#map-svg");
  svg.replaceChildren();

  const geometry = mapState.geometry || { provinces: [], headquarters: [] };

  // Landmass: province polygons with shared borders.
  const land = svgEl("g", { stroke: "#2c3a43", "stroke-width": "1" });
  for (const province of geometry.provinces) {
    const d = geometryToPath(province.geometry);
    if (!d) continue;
    const path = svgEl("path", { d, fill: "#16212a", "pointer-events": "none" });
    path.append(svgEl("title", {}, province.properties?.name || "Province"));
    land.append(path);
  }
  svg.append(land);

  // District headquarters: subtle dots, labels for major cities only.
  const hqLayer = svgEl("g", { fill: "#54646f" });
  for (const feature of geometry.headquarters) {
    const coordinates = feature.geometry?.coordinates;
    if (!coordinates) continue;
    const [x, y] = project(coordinates[1], coordinates[0]);
    const dot = svgEl("circle", { cx: x, cy: y, r: 2.2 });
    const name = feature.properties?.name || "District HQ";
    dot.append(svgEl("title", {}, name));
    hqLayer.append(dot);
    if (MAJOR_CITIES.has(name)) {
      hqLayer.append(
        svgEl(
          "text",
          { x: x + 5, y: y - 6, "font-size": "10", fill: "#8fa3b0" },
          name
        )
      );
    }
  }
  svg.append(hqLayer);

  // Incidents, at the coordinates their SOS packets carried.
  let located = 0;
  for (const incident of state.incidents) {
    if (typeof incident.lat !== "number" || typeof incident.lon !== "number") continue;
    const [x, y] = project(incident.lat, incident.lon);
    if (x < -40 || y < -40 || x > MAP_WIDTH + 40 || y > MAP_HEIGHT + 40) continue;
    located += 1;

    const coords = `${incident.lat.toFixed(5)}, ${incident.lon.toFixed(5)}`;
    const group = svgEl("g", {
      tabindex: "0",
      role: "button",
      "aria-label": `${incident.title}, priority ${Math.round(incident.priority)}, at ${coords}`,
    });
    group.append(
      svgEl(
        "title",
        {},
        `${incident.title}\n${coords}\nPriority ${Math.round(incident.priority)} · ${incident.reports} report(s)`
      )
    );

    group.append(
      svgEl("circle", {
        cx: x,
        cy: y,
        r: incident.severity === "critical" ? 18 : 13,
        fill: `var(--${incident.severity})`,
        opacity: "0.18",
      })
    );
    group.append(
      svgEl("circle", {
        cx: x,
        cy: y,
        r: incident.id === state.selectedId ? 8 : 6,
        fill: `var(--${incident.severity})`,
        stroke: incident.id === state.selectedId ? "#e8eef2" : "#0d1114",
        "stroke-width": "2",
      })
    );

    group.addEventListener("click", () => selectIncident(incident.id));
    group.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        selectIncident(incident.id);
      }
    });
    svg.append(group);

    if (incident.id === state.selectedId) {
      svg.append(
        svgEl(
          "text",
          { x: x + 11, y: y - 11, "font-size": "11", fill: "#e8eef2" },
          incident.title
        )
      );
    }
  }

  if (located === 0) {
    svg.append(
      svgEl(
        "text",
        {
          x: MAP_WIDTH / 2,
          y: MAP_HEIGHT - 60,
          "text-anchor": "middle",
          "font-size": "13",
          fill: "#6b7a85",
        },
        "No geolocated incidents yet — SOS coordinates appear here."
      )
    );
  }

  const note = $("#map-note");
  if (note) {
    note.textContent = mapState.failed
      ? "Basemap unavailable — incidents still listed"
      : `${located} located incident${located === 1 ? "" : "s"} · Nepal provinces (offline)`;
  }
}

function zoomMap(factor) {
  const next = mapState.view.zoom * factor;
  mapState.view.zoom = Math.min(40, Math.max(1, next));
}

function fitIncidents() {
  const located = state.incidents.filter(
    (incident) => typeof incident.lat === "number" && typeof incident.lon === "number"
  );
  if (located.length === 0) {
    mapState.view = { ...NEPAL_CENTER, zoom: 1 };
    return;
  }

  const lats = located.map((incident) => incident.lat);
  const lons = located.map((incident) => incident.lon);
  const lat = (Math.min(...lats) + Math.max(...lats)) / 2;
  const lon = (Math.min(...lons) + Math.max(...lons)) / 2;
  const latSpan = Math.max(0.05, Math.max(...lats) - Math.min(...lats));
  const lonSpan = Math.max(0.05, (Math.max(...lons) - Math.min(...lons)) * NEPAL.cos);

  const pxPerLat = (MAP_HEIGHT - MAP_PADDING * 2) / (NEPAL.north - NEPAL.south);
  const pxPerLon = (MAP_WIDTH - MAP_PADDING * 2) / ((NEPAL.east - NEPAL.west) * NEPAL.cos);
  const zoom = Math.min(30, 0.6 * Math.min(pxPerLat / latSpan, pxPerLon / lonSpan));
  mapState.view = { lat, lon, zoom: Math.max(1, zoom) };
}

function setupMapControls() {
  for (const button of document.querySelectorAll("[data-map-action]")) {
    button.addEventListener("click", () => {
      switch (button.dataset.mapAction) {
        case "zoom-in":
          zoomMap(1.6);
          break;
        case "zoom-out":
          zoomMap(1 / 1.6);
          break;
        case "focus":
          fitIncidents();
          break;
        case "reset":
        default:
          mapState.view = { ...NEPAL_CENTER, zoom: 1 };
      }
      renderMap();
    });
  }
}

// ---------- Health ----------

async function loadHealth() {
  const statusEl = $("#health-status");
  try {
    const response = await fetch("/api/v1/health", { headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const health = await response.json();
    statusEl.textContent = health.status === "ok" ? "● station healthy" : "● degraded";
    statusEl.className = `pill ${health.status === "ok" ? "ok" : "bad"}`;
    $("#health-ai").textContent =
      health.ai.runtime === "mock" ? "AI: mock" : `AI: ${health.ai.agent_mode}`;
    $("#health-mesh").textContent =
      health.mesh.mode === "demo" ? "Mesh: simulation" : "Mesh: offline";
  } catch {
    statusEl.textContent = "● gateway unreachable";
    statusEl.className = "pill bad";
  }
}

// ---------- Tabs & wiring ----------

function setupTabs() {
  for (const tab of document.querySelectorAll(".tab")) {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t === tab));
      document.querySelectorAll(".tab-panel").forEach((panel) => {
        panel.classList.toggle("active", panel.id === `panel-${tab.dataset.tab}`);
      });
    });
  }
}

function setupFilters() {
  $("#queue-search").addEventListener("input", (event) => {
    state.query = event.target.value;
    renderQueue();
  });
  $("#queue-status").addEventListener("change", (event) => {
    state.status = event.target.value;
    renderQueue();
  });
}

function tickClock() {
  $("#clock").textContent = new Date().toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

async function init() {
  await loadIncidents();
  await loadMapGeometry();
  if (state.incidents.length > 0 && state.selectedId === null) {
    state.selectedId = state.incidents[0].id;
  }
  renderQueue();
  renderDetail();
  renderMap();
  connectWS();
  loadHealth();
  tickClock();
}

setupTabs();
setupFilters();
setupMapControls();
init();
setInterval(tickClock, 1000);
setInterval(loadHealth, 30000);
setInterval(async () => {
  await loadIncidents();
  renderQueue();
  renderMap();
}, 10000);
